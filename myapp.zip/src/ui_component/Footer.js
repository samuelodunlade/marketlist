

const Footer = () => {
  return (
        <div className="row">
            <div className="col">
                <h1 className="text-center"> Footer </h1>
            </div>
        </div>
  )
}

export default Footer