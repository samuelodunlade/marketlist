

const Rich = () => {
  return (
    <h1 className="alert alert-success">
        You are doing well
    </h1>
  )
}

export default Rich