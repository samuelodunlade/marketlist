
const Balance = ({bal}) => {

  return (
    <div className="row">
        <div className="col">
           <h2>Your balance is <strong> {bal} </strong></h2>
        </div>
    </div>
  )
}

export default Balance