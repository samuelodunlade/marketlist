

const Broke = () => {
  return (
    <h1 className="alert alert-danger">
        You are currently broke
    </h1>
  )
}

export default Broke